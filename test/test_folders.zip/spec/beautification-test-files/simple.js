function hello(){console.log("hello");}
