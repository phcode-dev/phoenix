// Async fn def
var foo = { async bar() {} };
// ArrowExpression usage to define function
var fooAgain = () => {};