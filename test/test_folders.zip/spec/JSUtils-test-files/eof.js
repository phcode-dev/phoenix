function eofFunc() {
    // this is a fake brace: {
    var foo;
    if (foo) {
        alert("brace: }");
    }
}