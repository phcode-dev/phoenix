CHANGED/* Test comment */
CHANGEDdefine(function (require, exports, module) {
CHANGED    var Foo = require("modules/Foo"),
CHANGED        Bar = require("modules/Bar"),
CHANGED        Baz = require("modules/Baz");
CHANGED    
CHANGED    function callFoo() {
CHANGED        
CHANGED        foo();
CHANGED        
CHANGED    }
CHANGED
CHANGED}
CHANGED