var app = app || {};

(function () {
	'use strict';

    app.a = 1;

}());
