var myContent = "This is awesome!";
// Yes, it is!