/*jslint vars: true, plusplus: true, devel: true, regexp: true, nomen: true, indent: 4, maxerr: 50 */
/*global define, brackets, $ */

define(function (require, exports, module) {
    const NodeConnector = brackets.getModule("NodeConnector");
    const AppInit = brackets.getModule("utils/AppInit");
    const nodeConnector = NodeConnector.createNodeConnector("node-basic-required", exports);
    
    AppInit.appReady(function () {
        window._testNodeExtApi = function(){
            return nodeConnector.execPeer("echoTest", "yo!");
        };
    });
});

