`main` in `nodeConfig` points to a patch that doesnt exist
