Since `node/node_modules` folder exists, and `npmInstall` is set to true
inpackage.json, this extension install will fail
