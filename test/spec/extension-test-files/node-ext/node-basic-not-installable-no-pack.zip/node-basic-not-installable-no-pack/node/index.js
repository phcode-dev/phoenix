console.log("hello world node extension");

const extnNodeConnector = global.createNodeConnector("node-basic-not-installable", exports);

async function echoTest(name){
    return "hello from node " + name;
}

exports.echoTest = echoTest;